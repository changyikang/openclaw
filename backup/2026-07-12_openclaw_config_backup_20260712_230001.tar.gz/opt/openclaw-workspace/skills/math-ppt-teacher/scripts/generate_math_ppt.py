#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

from pptx import Presentation
from pptx.util import Pt


def default_outline(title: str, grade: str, topic: str):
    return [
        {"title": title, "bullets": [f"年级：{grade}", f"主题：{topic}", "目标：掌握核心概念并会解基础题"]},
        {"title": "课堂导入", "bullets": ["复习相关旧知", "引出本节核心问题", "明确学习目标"]},
        {"title": "核心概念", "bullets": [f"定义：{topic}相关核心定义", "关键词与符号说明", "与旧知的联系"]},
        {"title": "公式与方法", "bullets": ["给出核心公式/定理", "说明适用条件", "常见变形方法"]},
        {"title": "例题1（基础）", "bullets": ["题目：给出标准基础题", "步骤：列式→计算→结论", "强调每一步依据"]},
        {"title": "例题2（提升）", "bullets": ["题目：给出综合题", "步骤：分析已知条件→转化→求解", "对比例题1的差异"]},
        {"title": "易错点", "bullets": ["易错1：条件看漏", "易错2：符号/单位错误", "易错3：计算顺序不当"]},
        {"title": "课堂练习", "bullets": ["基础题 2-3 道", "提升题 1-2 道", "先独立完成，再讲评"]},
        {"title": "课堂小结", "bullets": ["本节关键词回顾", "解题步骤模板", "如何自查错误"]},
        {"title": "课后作业", "bullets": ["必做：基础巩固题", "选做：综合提升题", "预习下节内容"]},
    ]


def add_title_and_content_slide(prs: Presentation, title: str, bullets):
    layout = prs.slide_layouts[1]  # Title and Content
    slide = prs.slides.add_slide(layout)

    title_shape = slide.shapes.title
    title_shape.text = title
    title_shape.text_frame.paragraphs[0].font.size = Pt(34)

    content = slide.placeholders[1]
    tf = content.text_frame
    tf.clear()

    for i, b in enumerate(bullets):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = str(b)
        p.level = 0
        p.font.size = Pt(24)


def load_outline(path: str):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError("Outline JSON must be a list of slides")
    for item in data:
        if not isinstance(item, dict) or "title" not in item or "bullets" not in item:
            raise ValueError("Each slide must be {title, bullets}")
    return data


def main():
    parser = argparse.ArgumentParser(description="Generate middle-school math PPTX")
    parser.add_argument("--title", required=True)
    parser.add_argument("--grade", required=True)
    parser.add_argument("--topic", required=True)
    parser.add_argument("--outline-json", help="Path to JSON outline")
    parser.add_argument("--out", required=True, help="Output .pptx path")
    args = parser.parse_args()

    if args.outline_json:
        outline = load_outline(args.outline_json)
    else:
        outline = default_outline(args.title, args.grade, args.topic)

    prs = Presentation()

    for slide in outline:
        add_title_and_content_slide(prs, slide["title"], slide["bullets"])

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(out_path))

    print(f"Generated: {out_path}")


if __name__ == "__main__":
    main()
