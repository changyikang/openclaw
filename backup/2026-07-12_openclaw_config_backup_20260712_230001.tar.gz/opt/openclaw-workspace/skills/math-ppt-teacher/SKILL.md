---
name: math-ppt-teacher
description: Create middle-school math lesson slide decks (PPTX) with structured pedagogy, worked examples, and practice sets. Use when asked to prepare, revise, or export Chinese junior-high math teaching slides, including "知识点讲解", "例题", "课堂练习", and "课后作业".
---

# Math PPT Teacher

Build a concise, classroom-ready PPTX for junior-high math.

## Workflow

1. Clarify grade, topic, class length, and difficulty.
2. Draft a slide outline using `references/outline-template.md`.
3. Generate the PPTX with `scripts/generate_math_ppt.py`.
4. Quickly review wording length and slide count (target 10–16 slides for a 40–45 min class).

## Default slide structure

1. Title + lesson goals
2. Warm-up review (2–3 quick questions)
3. Core concept explanation
4. Formula/rule summary
5. Worked Example 1 (step-by-step)
6. Worked Example 2 (step-by-step)
7. Common mistakes
8. In-class practice (3–5 questions)
9. Exit ticket / quick check
10. Homework and recap

Adjust the number of example/practice slides based on class duration.

## Generate PPTX

Run:

```bash
python3 skills/math-ppt-teacher/scripts/generate_math_ppt.py \
  --title "七年级数学：一次函数入门" \
  --grade "七年级" \
  --topic "一次函数" \
  --out "/home/kang/kangTest/七年级-一次函数-示例课件.pptx"
```

Optional: pass a JSON outline file.

```bash
python3 skills/math-ppt-teacher/scripts/generate_math_ppt.py \
  --title "八年级数学：勾股定理" \
  --grade "八年级" \
  --topic "勾股定理" \
  --outline-json "/path/to/outline.json" \
  --out "/path/to/output.pptx"
```

JSON format:

```json
[
  {"title": "教学目标", "bullets": ["...", "..."]},
  {"title": "例题1", "bullets": ["题目：...", "解：..."]}
]
```

## Quality rules

- Keep each bullet under ~28 Chinese characters when possible.
- Use one key idea per slide.
- For example slides, always include both "题目" and "解题步骤".
- Include at least one "易错点" slide and one "课堂练习" slide.
